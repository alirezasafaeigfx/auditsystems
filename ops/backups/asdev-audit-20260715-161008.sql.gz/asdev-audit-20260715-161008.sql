--
-- PostgreSQL database dump
--

\restrict UL52oAkESX1Oeed3Wr6eYggZmRbs3Jesdmq0tgbIpXeqEIpouniw1knwmTOxDmT

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."UsageLedger" DROP CONSTRAINT IF EXISTS "UsageLedger_organizationId_fkey";
ALTER TABLE IF EXISTS ONLY public."Subscription" DROP CONSTRAINT IF EXISTS "Subscription_planId_fkey";
ALTER TABLE IF EXISTS ONLY public."Subscription" DROP CONSTRAINT IF EXISTS "Subscription_organizationId_fkey";
ALTER TABLE IF EXISTS ONLY public."Session" DROP CONSTRAINT IF EXISTS "Session_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."ScheduledAudit" DROP CONSTRAINT IF EXISTS "ScheduledAudit_projectId_fkey";
ALTER TABLE IF EXISTS ONLY public."ScheduledAudit" DROP CONSTRAINT IF EXISTS "ScheduledAudit_organizationId_fkey";
ALTER TABLE IF EXISTS ONLY public."ReportShare" DROP CONSTRAINT IF EXISTS "ReportShare_runId_fkey";
ALTER TABLE IF EXISTS ONLY public."Project" DROP CONSTRAINT IF EXISTS "Project_organizationId_fkey";
ALTER TABLE IF EXISTS ONLY public."Membership" DROP CONSTRAINT IF EXISTS "Membership_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."Membership" DROP CONSTRAINT IF EXISTS "Membership_organizationId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_subscriptionId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_planId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_organizationId_fkey";
ALTER TABLE IF EXISTS ONLY public."FunnelEvent" DROP CONSTRAINT IF EXISTS "FunnelEvent_runId_fkey";
ALTER TABLE IF EXISTS ONLY public."FunnelEvent" DROP CONSTRAINT IF EXISTS "FunnelEvent_leadId_fkey";
ALTER TABLE IF EXISTS ONLY public."EmailVerificationToken" DROP CONSTRAINT IF EXISTS "EmailVerificationToken_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditRun" DROP CONSTRAINT IF EXISTS "AuditRun_projectId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditRun" DROP CONSTRAINT IF EXISTS "AuditRun_organizationId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditResource" DROP CONSTRAINT IF EXISTS "AuditResource_runId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditOrder" DROP CONSTRAINT IF EXISTS "AuditOrder_runId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditOrderEvent" DROP CONSTRAINT IF EXISTS "AuditOrderEvent_orderId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditLead" DROP CONSTRAINT IF EXISTS "AuditLead_runId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditFinding" DROP CONSTRAINT IF EXISTS "AuditFinding_runId_fkey";
DROP INDEX IF EXISTS public."User_email_key";
DROP INDEX IF EXISTS public."UsageLedger_organizationId_type_createdAt_idx";
DROP INDEX IF EXISTS public."Subscription_planId_idx";
DROP INDEX IF EXISTS public."Subscription_organizationId_status_idx";
DROP INDEX IF EXISTS public."Session_userId_idx";
DROP INDEX IF EXISTS public."Session_token_key";
DROP INDEX IF EXISTS public."Session_token_idx";
DROP INDEX IF EXISTS public."ScheduledAudit_organizationId_enabled_idx";
DROP INDEX IF EXISTS public."ScheduledAudit_nextRunAt_enabled_idx";
DROP INDEX IF EXISTS public."ReportShare_token_key";
DROP INDEX IF EXISTS public."ReportShare_runId_idx";
DROP INDEX IF EXISTS public."Project_organizationId_idx";
DROP INDEX IF EXISTS public."Plan_code_key";
DROP INDEX IF EXISTS public."Organization_slug_key";
DROP INDEX IF EXISTS public."Membership_userId_organizationId_key";
DROP INDEX IF EXISTS public."Membership_organizationId_idx";
DROP INDEX IF EXISTS public."Job_type_status_idx";
DROP INDEX IF EXISTS public."Job_status_availableAt_idx";
DROP INDEX IF EXISTS public."Job_leasedUntil_idx";
DROP INDEX IF EXISTS public."Invoice_organizationId_status_idx";
DROP INDEX IF EXISTS public."Invoice_callbackRef_idx";
DROP INDEX IF EXISTS public."FunnelEvent_source_createdAt_idx";
DROP INDEX IF EXISTS public."FunnelEvent_runId_createdAt_idx";
DROP INDEX IF EXISTS public."FunnelEvent_leadId_createdAt_idx";
DROP INDEX IF EXISTS public."FunnelEvent_eventType_createdAt_idx";
DROP INDEX IF EXISTS public."EmailVerificationToken_userId_createdAt_idx";
DROP INDEX IF EXISTS public."EmailVerificationToken_tokenHash_key";
DROP INDEX IF EXISTS public."AuditRun_status_createdAt_idx";
DROP INDEX IF EXISTS public."AuditRun_projectId_createdAt_idx";
DROP INDEX IF EXISTS public."AuditRun_organizationId_createdAt_idx";
DROP INDEX IF EXISTS public."AuditRun_normalizedUrl_createdAt_idx";
DROP INDEX IF EXISTS public."AuditResource_runId_isThirdParty_idx";
DROP INDEX IF EXISTS public."AuditResource_host_idx";
DROP INDEX IF EXISTS public."AuditOrder_runId_status_idx";
DROP INDEX IF EXISTS public."AuditOrder_email_createdAt_idx";
DROP INDEX IF EXISTS public."AuditOrderEvent_orderId_createdAt_idx";
DROP INDEX IF EXISTS public."AuditLead_status_createdAt_idx";
DROP INDEX IF EXISTS public."AuditLead_runId_createdAt_idx";
DROP INDEX IF EXISTS public."AuditLead_leadSource_createdAt_idx";
DROP INDEX IF EXISTS public."AuditLead_email_createdAt_idx";
DROP INDEX IF EXISTS public."AuditLead_domain_createdAt_idx";
DROP INDEX IF EXISTS public."AuditFinding_runId_category_severity_idx";
DROP INDEX IF EXISTS public."AuditFinding_code_idx";
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_pkey";
ALTER TABLE IF EXISTS ONLY public."UsageLedger" DROP CONSTRAINT IF EXISTS "UsageLedger_pkey";
ALTER TABLE IF EXISTS ONLY public."Subscription" DROP CONSTRAINT IF EXISTS "Subscription_pkey";
ALTER TABLE IF EXISTS ONLY public."Session" DROP CONSTRAINT IF EXISTS "Session_pkey";
ALTER TABLE IF EXISTS ONLY public."ScheduledAudit" DROP CONSTRAINT IF EXISTS "ScheduledAudit_pkey";
ALTER TABLE IF EXISTS ONLY public."ReportShare" DROP CONSTRAINT IF EXISTS "ReportShare_pkey";
ALTER TABLE IF EXISTS ONLY public."Project" DROP CONSTRAINT IF EXISTS "Project_pkey";
ALTER TABLE IF EXISTS ONLY public."Plan" DROP CONSTRAINT IF EXISTS "Plan_pkey";
ALTER TABLE IF EXISTS ONLY public."Organization" DROP CONSTRAINT IF EXISTS "Organization_pkey";
ALTER TABLE IF EXISTS ONLY public."Membership" DROP CONSTRAINT IF EXISTS "Membership_pkey";
ALTER TABLE IF EXISTS ONLY public."Job" DROP CONSTRAINT IF EXISTS "Job_pkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_pkey";
ALTER TABLE IF EXISTS ONLY public."FunnelEvent" DROP CONSTRAINT IF EXISTS "FunnelEvent_pkey";
ALTER TABLE IF EXISTS ONLY public."EmailVerificationToken" DROP CONSTRAINT IF EXISTS "EmailVerificationToken_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditRun" DROP CONSTRAINT IF EXISTS "AuditRun_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditResource" DROP CONSTRAINT IF EXISTS "AuditResource_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditOrder" DROP CONSTRAINT IF EXISTS "AuditOrder_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditOrderEvent" DROP CONSTRAINT IF EXISTS "AuditOrderEvent_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditLead" DROP CONSTRAINT IF EXISTS "AuditLead_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditFinding" DROP CONSTRAINT IF EXISTS "AuditFinding_pkey";
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TABLE IF EXISTS public."User";
DROP TABLE IF EXISTS public."UsageLedger";
DROP TABLE IF EXISTS public."Subscription";
DROP TABLE IF EXISTS public."Session";
DROP TABLE IF EXISTS public."ScheduledAudit";
DROP TABLE IF EXISTS public."ReportShare";
DROP TABLE IF EXISTS public."Project";
DROP TABLE IF EXISTS public."Plan";
DROP TABLE IF EXISTS public."Organization";
DROP TABLE IF EXISTS public."Membership";
DROP TABLE IF EXISTS public."Job";
DROP TABLE IF EXISTS public."Invoice";
DROP TABLE IF EXISTS public."FunnelEvent";
DROP TABLE IF EXISTS public."EmailVerificationToken";
DROP TABLE IF EXISTS public."AuditRun";
DROP TABLE IF EXISTS public."AuditResource";
DROP TABLE IF EXISTS public."AuditOrderEvent";
DROP TABLE IF EXISTS public."AuditOrder";
DROP TABLE IF EXISTS public."AuditLead";
DROP TABLE IF EXISTS public."AuditFinding";
DROP TYPE IF EXISTS public."PaymentProvider";
DROP TYPE IF EXISTS public."OrderStatus";
DROP TYPE IF EXISTS public."LeadStatus";
DROP TYPE IF EXISTS public."JobType";
DROP TYPE IF EXISTS public."JobStatus";
DROP TYPE IF EXISTS public."FindingSeverity";
DROP TYPE IF EXISTS public."FindingCategory";
DROP TYPE IF EXISTS public."AuditStatus";
DROP TYPE IF EXISTS public."AuditReportStatus";
DROP TYPE IF EXISTS public."AuditDepth";
--
-- Name: AuditDepth; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditDepth" AS ENUM (
    'QUICK',
    'DEEP'
);


--
-- Name: AuditReportStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditReportStatus" AS ENUM (
    'QUEUED',
    'RUNNING',
    'REVIEW',
    'DELIVERED',
    'FAILED'
);


--
-- Name: AuditStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AuditStatus" AS ENUM (
    'QUEUED',
    'RUNNING',
    'SUCCEEDED',
    'FAILED'
);


--
-- Name: FindingCategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FindingCategory" AS ENUM (
    'RESILIENCE',
    'PERFORMANCE',
    'SEO',
    'SECURITY',
    'UX',
    'ACCESSIBILITY'
);


--
-- Name: FindingSeverity; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FindingSeverity" AS ENUM (
    'INFO',
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


--
-- Name: JobStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobStatus" AS ENUM (
    'QUEUED',
    'RUNNING',
    'SUCCEEDED',
    'FAILED'
);


--
-- Name: JobType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobType" AS ENUM (
    'AUDIT_RUN'
);


--
-- Name: LeadStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LeadStatus" AS ENUM (
    'NEW',
    'QUALIFIED',
    'AUDIT_STARTED',
    'REPORT_READY',
    'DELIVERED',
    'CONVERTED',
    'LOST'
);


--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED',
    'CANCELED',
    'EXPIRED'
);


--
-- Name: PaymentProvider; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentProvider" AS ENUM (
    'ZARINPAL',
    'IDPAY',
    'PAYPING',
    'MOCK'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditFinding; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditFinding" (
    id text NOT NULL,
    "runId" text NOT NULL,
    category public."FindingCategory" NOT NULL,
    severity public."FindingSeverity" NOT NULL,
    code text NOT NULL,
    title text NOT NULL,
    description text,
    recommendation text,
    evidence jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AuditLead; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLead" (
    id text NOT NULL,
    "runId" text,
    email text NOT NULL,
    name text,
    phone text,
    company text,
    note text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    domain text NOT NULL,
    "normalizedUrl" text,
    "businessType" text NOT NULL,
    "primaryConcern" text NOT NULL,
    "consentPrivacy" boolean DEFAULT false NOT NULL,
    status public."LeadStatus" DEFAULT 'NEW'::public."LeadStatus" NOT NULL,
    "internalNote" text,
    "nextActionAt" timestamp(3) without time zone,
    "lostReason" text,
    "leadSource" text DEFAULT 'direct'::text NOT NULL,
    "sourcePlacement" text,
    "sourceOffer" text,
    "submitEventId" text,
    "qualifiedAt" timestamp(3) without time zone,
    "lostAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "convertedAt" timestamp(3) without time zone
);


--
-- Name: AuditOrder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditOrder" (
    id text NOT NULL,
    "runId" text NOT NULL,
    email text NOT NULL,
    "amountToman" integer NOT NULL,
    status public."OrderStatus" DEFAULT 'PENDING'::public."OrderStatus" NOT NULL,
    provider public."PaymentProvider" DEFAULT 'MOCK'::public."PaymentProvider" NOT NULL,
    "providerRef" text,
    "callbackRef" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "canceledAt" timestamp(3) without time zone
);


--
-- Name: AuditOrderEvent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditOrderEvent" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    kind text NOT NULL,
    payload jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AuditResource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditResource" (
    id text NOT NULL,
    "runId" text NOT NULL,
    kind text NOT NULL,
    url text NOT NULL,
    host text,
    "isThirdParty" boolean DEFAULT false NOT NULL,
    "inHead" boolean,
    attrs jsonb,
    "riskTag" text,
    "sizeBytes" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AuditRun; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditRun" (
    id text NOT NULL,
    url text NOT NULL,
    "normalizedUrl" text,
    depth public."AuditDepth" DEFAULT 'QUICK'::public."AuditDepth" NOT NULL,
    status public."AuditStatus" DEFAULT 'QUEUED'::public."AuditStatus" NOT NULL,
    "ipHash" text,
    "userAgent" text,
    locale text,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    "errorCode" text,
    "errorMessage" text,
    summary jsonb,
    lighthouse jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "projectId" text,
    "organizationId" text,
    "reportStatus" public."AuditReportStatus" DEFAULT 'QUEUED'::public."AuditReportStatus" NOT NULL
);


--
-- Name: EmailVerificationToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailVerificationToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: FunnelEvent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FunnelEvent" (
    id text NOT NULL,
    "eventType" text NOT NULL,
    "leadId" text,
    "runId" text,
    source text,
    placement text,
    offer text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    "subscriptionId" text,
    "planId" text NOT NULL,
    "amountToman" integer NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    provider public."PaymentProvider" DEFAULT 'MOCK'::public."PaymentProvider" NOT NULL,
    "providerRef" text,
    "callbackRef" text,
    "paidAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Job; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Job" (
    id text NOT NULL,
    type public."JobType" NOT NULL,
    status public."JobStatus" DEFAULT 'QUEUED'::public."JobStatus" NOT NULL,
    payload jsonb NOT NULL,
    attempt integer DEFAULT 0 NOT NULL,
    "maxAttempts" integer DEFAULT 3 NOT NULL,
    "timeoutMs" integer DEFAULT 45000 NOT NULL,
    "availableAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lockedAt" timestamp(3) without time zone,
    "leasedUntil" timestamp(3) without time zone,
    "workerId" text,
    "lastError" text,
    "startedAt" timestamp(3) without time zone,
    "finishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Membership; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Membership" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "organizationId" text NOT NULL,
    role text DEFAULT 'OWNER'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Organization; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Plan; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Plan" (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    "priceMonthlyToman" integer DEFAULT 0 NOT NULL,
    "projectLimit" integer DEFAULT 1 NOT NULL,
    "monthlyAuditLimit" integer DEFAULT 3 NOT NULL,
    "pdfExport" boolean DEFAULT false NOT NULL,
    "scheduledAudits" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Project" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    name text NOT NULL,
    domain text NOT NULL,
    "normalizedUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ReportShare; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ReportShare" (
    id text NOT NULL,
    "runId" text NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "revokedAt" timestamp(3) without time zone,
    "viewCount" integer DEFAULT 0 NOT NULL,
    "lastViewedAt" timestamp(3) without time zone,
    "passwordHash" text
);


--
-- Name: ScheduledAudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ScheduledAudit" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    "projectId" text NOT NULL,
    frequency text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    "nextRunAt" timestamp(3) without time zone NOT NULL,
    "lastRunAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    "planId" text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: UsageLedger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."UsageLedger" (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    type text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    name text,
    "passwordHash" text NOT NULL,
    "emailVerifiedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AuditFinding; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditFinding" (id, "runId", category, severity, code, title, description, recommendation, evidence, "createdAt") FROM stdin;
\.


--
-- Data for Name: AuditLead; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLead" (id, "runId", email, name, phone, company, note, "createdAt", domain, "normalizedUrl", "businessType", "primaryConcern", "consentPrivacy", status, "internalNote", "nextActionAt", "lostReason", "leadSource", "sourcePlacement", "sourceOffer", "submitEventId", "qualifiedAt", "lostAt", "updatedAt", "convertedAt") FROM stdin;
\.


--
-- Data for Name: AuditOrder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditOrder" (id, "runId", email, "amountToman", status, provider, "providerRef", "callbackRef", "createdAt", "paidAt", "canceledAt") FROM stdin;
\.


--
-- Data for Name: AuditOrderEvent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditOrderEvent" (id, "orderId", kind, payload, "createdAt") FROM stdin;
\.


--
-- Data for Name: AuditResource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditResource" (id, "runId", kind, url, host, "isThirdParty", "inHead", attrs, "riskTag", "sizeBytes", "createdAt") FROM stdin;
\.


--
-- Data for Name: AuditRun; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditRun" (id, url, "normalizedUrl", depth, status, "ipHash", "userAgent", locale, "startedAt", "finishedAt", "errorCode", "errorMessage", summary, lighthouse, "createdAt", "updatedAt", "projectId", "organizationId", "reportStatus") FROM stdin;
\.


--
-- Data for Name: EmailVerificationToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."EmailVerificationToken" (id, "userId", "tokenHash", "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: FunnelEvent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."FunnelEvent" (id, "eventType", "leadId", "runId", source, placement, offer, metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Invoice" (id, "organizationId", "subscriptionId", "planId", "amountToman", status, provider, "providerRef", "callbackRef", "paidAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Job; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Job" (id, type, status, payload, attempt, "maxAttempts", "timeoutMs", "availableAt", "lockedAt", "leasedUntil", "workerId", "lastError", "startedAt", "finishedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Membership; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Membership" (id, "userId", "organizationId", role, "createdAt") FROM stdin;
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Organization" (id, name, slug, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Plan; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Plan" (id, code, name, "priceMonthlyToman", "projectLimit", "monthlyAuditLimit", "pdfExport", "scheduledAudits", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Project" (id, "organizationId", name, domain, "normalizedUrl", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ReportShare; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ReportShare" (id, "runId", token, "createdAt", "expiresAt", "revokedAt", "viewCount", "lastViewedAt", "passwordHash") FROM stdin;
\.


--
-- Data for Name: ScheduledAudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ScheduledAudit" (id, "organizationId", "projectId", frequency, enabled, "nextRunAt", "lastRunAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "userId", token, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Subscription" (id, "organizationId", "planId", status, "currentPeriodStart", "currentPeriodEnd", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: UsageLedger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."UsageLedger" (id, "organizationId", type, quantity, metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, name, "passwordHash", "emailVerifiedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
80a18f05-bd40-43c1-bf0b-46e9c3d1ef3a	241258f873fa79b3ae8747e084c5bd26bc00f552ca9f60739ee5d81926a210e1	2026-07-15 16:06:41.009354+00	0001_init	\N	\N	2026-07-15 16:06:40.891377+00	1
157fbd59-684a-4cf8-b205-51172e603da6	5d0d670a2d4f48f6c443621931b1513f1bdbc928e81b54a4c326dfdd4ed5b366	2026-07-15 16:06:41.01854+00	20250111000000_add_accessibility_finding_category	\N	\N	2026-07-15 16:06:41.011619+00	1
0d6856e5-f5d6-433b-8788-2bc7320990d8	1009d4bca726bc8e92f620451a28286eeccd5f9e686d5bae7c1f0aacb2b70828	2026-07-15 16:06:41.025946+00	20260611123847_add_accessibility_finding_category	\N	\N	2026-07-15 16:06:41.020723+00	1
67b88b06-0261-47d4-8857-2aa4380ae344	1171dd0663d35689bd4398235fc7aa6cdafcceed281b3a1619cc7727645cd54b	2026-07-15 16:06:41.09824+00	20260704_saas_foundation	\N	\N	2026-07-15 16:06:41.028852+00	1
c4df04ab-c4a0-464c-a3e7-4ed565110ab4	77bbe1dbacca468b23010b2d8c186a16ae9de75c3e1b1fb6beb6f296d5ebc45c	2026-07-15 16:06:41.171138+00	20260705_sprint3_revenue_retention	\N	\N	2026-07-15 16:06:41.100925+00	1
fdbb6b8b-ad7b-4dde-85eb-9317fa6addb2	8bf0780bd32421302bc5cfe6a86fbc9d5a40397917fe31ae96be977179113cc4	2026-07-15 16:06:41.215228+00	20260710_revenue_lead_delivery	\N	\N	2026-07-15 16:06:41.172366+00	1
764029f8-27bc-41d7-ae58-fa19d34fce46	bfd260f641bcf5400ad51b45fb4061296d4ad6f8d4a63784d254acaac3f52b5d	2026-07-15 16:06:41.242744+00	20260711000000_lead_lifecycle_upgrade	\N	\N	2026-07-15 16:06:41.217128+00	1
\.


--
-- Name: AuditFinding AuditFinding_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditFinding"
    ADD CONSTRAINT "AuditFinding_pkey" PRIMARY KEY (id);


--
-- Name: AuditLead AuditLead_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLead"
    ADD CONSTRAINT "AuditLead_pkey" PRIMARY KEY (id);


--
-- Name: AuditOrderEvent AuditOrderEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditOrderEvent"
    ADD CONSTRAINT "AuditOrderEvent_pkey" PRIMARY KEY (id);


--
-- Name: AuditOrder AuditOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditOrder"
    ADD CONSTRAINT "AuditOrder_pkey" PRIMARY KEY (id);


--
-- Name: AuditResource AuditResource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditResource"
    ADD CONSTRAINT "AuditResource_pkey" PRIMARY KEY (id);


--
-- Name: AuditRun AuditRun_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditRun"
    ADD CONSTRAINT "AuditRun_pkey" PRIMARY KEY (id);


--
-- Name: EmailVerificationToken EmailVerificationToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailVerificationToken"
    ADD CONSTRAINT "EmailVerificationToken_pkey" PRIMARY KEY (id);


--
-- Name: FunnelEvent FunnelEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FunnelEvent"
    ADD CONSTRAINT "FunnelEvent_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: Job Job_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_pkey" PRIMARY KEY (id);


--
-- Name: Membership Membership_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: Plan Plan_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Plan"
    ADD CONSTRAINT "Plan_pkey" PRIMARY KEY (id);


--
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- Name: ReportShare ReportShare_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ReportShare"
    ADD CONSTRAINT "ReportShare_pkey" PRIMARY KEY (id);


--
-- Name: ScheduledAudit ScheduledAudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ScheduledAudit"
    ADD CONSTRAINT "ScheduledAudit_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: UsageLedger UsageLedger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UsageLedger"
    ADD CONSTRAINT "UsageLedger_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AuditFinding_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditFinding_code_idx" ON public."AuditFinding" USING btree (code);


--
-- Name: AuditFinding_runId_category_severity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditFinding_runId_category_severity_idx" ON public."AuditFinding" USING btree ("runId", category, severity);


--
-- Name: AuditLead_domain_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLead_domain_createdAt_idx" ON public."AuditLead" USING btree (domain, "createdAt");


--
-- Name: AuditLead_email_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLead_email_createdAt_idx" ON public."AuditLead" USING btree (email, "createdAt");


--
-- Name: AuditLead_leadSource_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLead_leadSource_createdAt_idx" ON public."AuditLead" USING btree ("leadSource", "createdAt");


--
-- Name: AuditLead_runId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLead_runId_createdAt_idx" ON public."AuditLead" USING btree ("runId", "createdAt");


--
-- Name: AuditLead_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLead_status_createdAt_idx" ON public."AuditLead" USING btree (status, "createdAt");


--
-- Name: AuditOrderEvent_orderId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditOrderEvent_orderId_createdAt_idx" ON public."AuditOrderEvent" USING btree ("orderId", "createdAt");


--
-- Name: AuditOrder_email_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditOrder_email_createdAt_idx" ON public."AuditOrder" USING btree (email, "createdAt");


--
-- Name: AuditOrder_runId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditOrder_runId_status_idx" ON public."AuditOrder" USING btree ("runId", status);


--
-- Name: AuditResource_host_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditResource_host_idx" ON public."AuditResource" USING btree (host);


--
-- Name: AuditResource_runId_isThirdParty_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditResource_runId_isThirdParty_idx" ON public."AuditResource" USING btree ("runId", "isThirdParty");


--
-- Name: AuditRun_normalizedUrl_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditRun_normalizedUrl_createdAt_idx" ON public."AuditRun" USING btree ("normalizedUrl", "createdAt");


--
-- Name: AuditRun_organizationId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditRun_organizationId_createdAt_idx" ON public."AuditRun" USING btree ("organizationId", "createdAt");


--
-- Name: AuditRun_projectId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditRun_projectId_createdAt_idx" ON public."AuditRun" USING btree ("projectId", "createdAt");


--
-- Name: AuditRun_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditRun_status_createdAt_idx" ON public."AuditRun" USING btree (status, "createdAt");


--
-- Name: EmailVerificationToken_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "EmailVerificationToken_tokenHash_key" ON public."EmailVerificationToken" USING btree ("tokenHash");


--
-- Name: EmailVerificationToken_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "EmailVerificationToken_userId_createdAt_idx" ON public."EmailVerificationToken" USING btree ("userId", "createdAt");


--
-- Name: FunnelEvent_eventType_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FunnelEvent_eventType_createdAt_idx" ON public."FunnelEvent" USING btree ("eventType", "createdAt");


--
-- Name: FunnelEvent_leadId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FunnelEvent_leadId_createdAt_idx" ON public."FunnelEvent" USING btree ("leadId", "createdAt");


--
-- Name: FunnelEvent_runId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FunnelEvent_runId_createdAt_idx" ON public."FunnelEvent" USING btree ("runId", "createdAt");


--
-- Name: FunnelEvent_source_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "FunnelEvent_source_createdAt_idx" ON public."FunnelEvent" USING btree (source, "createdAt");


--
-- Name: Invoice_callbackRef_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_callbackRef_idx" ON public."Invoice" USING btree ("callbackRef");


--
-- Name: Invoice_organizationId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Invoice_organizationId_status_idx" ON public."Invoice" USING btree ("organizationId", status);


--
-- Name: Job_leasedUntil_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Job_leasedUntil_idx" ON public."Job" USING btree ("leasedUntil");


--
-- Name: Job_status_availableAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Job_status_availableAt_idx" ON public."Job" USING btree (status, "availableAt");


--
-- Name: Job_type_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Job_type_status_idx" ON public."Job" USING btree (type, status);


--
-- Name: Membership_organizationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Membership_organizationId_idx" ON public."Membership" USING btree ("organizationId");


--
-- Name: Membership_userId_organizationId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Membership_userId_organizationId_key" ON public."Membership" USING btree ("userId", "organizationId");


--
-- Name: Organization_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Organization_slug_key" ON public."Organization" USING btree (slug);


--
-- Name: Plan_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Plan_code_key" ON public."Plan" USING btree (code);


--
-- Name: Project_organizationId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Project_organizationId_idx" ON public."Project" USING btree ("organizationId");


--
-- Name: ReportShare_runId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ReportShare_runId_idx" ON public."ReportShare" USING btree ("runId");


--
-- Name: ReportShare_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "ReportShare_token_key" ON public."ReportShare" USING btree (token);


--
-- Name: ScheduledAudit_nextRunAt_enabled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ScheduledAudit_nextRunAt_enabled_idx" ON public."ScheduledAudit" USING btree ("nextRunAt", enabled);


--
-- Name: ScheduledAudit_organizationId_enabled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ScheduledAudit_organizationId_enabled_idx" ON public."ScheduledAudit" USING btree ("organizationId", enabled);


--
-- Name: Session_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_token_idx" ON public."Session" USING btree (token);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: Subscription_organizationId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Subscription_organizationId_status_idx" ON public."Subscription" USING btree ("organizationId", status);


--
-- Name: Subscription_planId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Subscription_planId_idx" ON public."Subscription" USING btree ("planId");


--
-- Name: UsageLedger_organizationId_type_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "UsageLedger_organizationId_type_createdAt_idx" ON public."UsageLedger" USING btree ("organizationId", type, "createdAt");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: AuditFinding AuditFinding_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditFinding"
    ADD CONSTRAINT "AuditFinding_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."AuditRun"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLead AuditLead_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLead"
    ADD CONSTRAINT "AuditLead_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."AuditRun"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditOrderEvent AuditOrderEvent_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditOrderEvent"
    ADD CONSTRAINT "AuditOrderEvent_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."AuditOrder"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditOrder AuditOrder_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditOrder"
    ADD CONSTRAINT "AuditOrder_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."AuditRun"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditResource AuditResource_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditResource"
    ADD CONSTRAINT "AuditResource_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."AuditRun"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditRun AuditRun_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditRun"
    ADD CONSTRAINT "AuditRun_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditRun AuditRun_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditRun"
    ADD CONSTRAINT "AuditRun_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EmailVerificationToken EmailVerificationToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailVerificationToken"
    ADD CONSTRAINT "EmailVerificationToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FunnelEvent FunnelEvent_leadId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FunnelEvent"
    ADD CONSTRAINT "FunnelEvent_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES public."AuditLead"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: FunnelEvent FunnelEvent_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FunnelEvent"
    ADD CONSTRAINT "FunnelEvent_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."AuditRun"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Invoice Invoice_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoice Invoice_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invoice Invoice_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Membership Membership_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Membership Membership_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Membership"
    ADD CONSTRAINT "Membership_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Project Project_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ReportShare ReportShare_runId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ReportShare"
    ADD CONSTRAINT "ReportShare_runId_fkey" FOREIGN KEY ("runId") REFERENCES public."AuditRun"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ScheduledAudit ScheduledAudit_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ScheduledAudit"
    ADD CONSTRAINT "ScheduledAudit_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ScheduledAudit ScheduledAudit_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ScheduledAudit"
    ADD CONSTRAINT "ScheduledAudit_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subscription Subscription_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subscription Subscription_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_planId_fkey" FOREIGN KEY ("planId") REFERENCES public."Plan"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UsageLedger UsageLedger_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."UsageLedger"
    ADD CONSTRAINT "UsageLedger_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict UL52oAkESX1Oeed3Wr6eYggZmRbs3Jesdmq0tgbIpXeqEIpouniw1knwmTOxDmT

